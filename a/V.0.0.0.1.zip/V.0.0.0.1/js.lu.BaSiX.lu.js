/* @ All Headers, Libraries and Costhom classes/conventions to Include @ */

/* @Add :: */ //import { ApexAbstract } from /* BlueDiamondLazer */ './jesus=jesus.js';
/* @Add :: */ //let Apex = new ApexAbstract.Phantom();

/* @Add :: */
/* @Add :: */

/* @Add :: */
/* @Add :: */

export const BaSiX = ( () => {

  class BSX {

    constructor(){

    } /* initialization */

    Apex(){ /* @Add :: BSX.Apex  */
      //return /* <== */ Apex;
    }

  }

  class crustomclass {

    constructor(){}

    crazyConventionName(){
      // tada...
      return 'zoo';
    }

  }

  return { /* Always add@ ClassName:ClassName ; SiliconName:SiliconName */
    BSX : BSX,
    crustomclass : crustomclass,
  }

}) (); /* BSX */
